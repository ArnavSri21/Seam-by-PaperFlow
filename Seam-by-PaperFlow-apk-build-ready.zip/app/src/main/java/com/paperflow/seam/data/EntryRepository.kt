package com.paperflow.seam.data
import kotlinx.coroutines.flow.Flow
import java.util.UUID
class EntryRepository(private val dao:EntryDao){
 fun all():Flow<List<Entry>> = dao.all()
 fun search(q:String):Flow<List<Entry>> = dao.search(q)
 suspend fun add(title:String,body:String){dao.save(Entry(UUID.randomUUID().toString(),title,body))}
}
