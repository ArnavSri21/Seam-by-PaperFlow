package com.paperflow.seam.worker
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit
class AnalysisWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){
 override suspend fun doWork():Result {
  // TODO: bounded, resumable on-device tagging/indexing for permitted non-secret content.
  // Never enqueue password-vault data or upload content without explicit consent.
  return Result.success()
 }
}
object AnalysisSchedule {
 fun start(context:Context){
  val request=PeriodicWorkRequestBuilder<AnalysisWorker>(12,TimeUnit.HOURS)
   .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).setRequiredNetworkType(NetworkType.NOT_REQUIRED).build()).build()
  WorkManager.getInstance(context).enqueueUniquePeriodicWork("seam-local-analysis",ExistingPeriodicWorkPolicy.KEEP,request)
 }
}
