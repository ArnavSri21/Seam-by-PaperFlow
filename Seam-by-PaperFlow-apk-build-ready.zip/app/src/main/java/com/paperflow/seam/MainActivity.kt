package com.paperflow.seam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperflow.seam.data.*
import com.paperflow.seam.worker.AnalysisSchedule
import kotlinx.coroutines.launch

private val Black = Color(0xFF08090B)
private val Surface = Color(0xFF17181B)
private val Surface2 = Color(0xFF202124)
private val White = Color(0xFFF2F1EF)
private val Grey = Color(0xFF96979B)
private val Silver = Color(0xFFD4D4D2)
private val Glow = Color(0xFFBFC1C6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AnalysisSchedule.start(this)
        val repository = EntryRepository(SeamDatabase.get(this).entries())
        setContent { SeamApp(repository) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeamApp(repository: EntryRepository) {
    var page by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val entries by (if (search.isBlank()) repository.all() else repository.search(search))
        .collectAsStateWithLifecycle(initialValue = emptyList())

    MaterialTheme(colorScheme = darkColorScheme(
        background = Black, surface = Surface, primary = Silver,
        onBackground = White, onSurface = White, secondary = Grey
    )) {
        Box(Modifier.fillMaxSize().background(Black)) {
            AmbientBackdrop()
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { SeamBottomBar(page) { page = it } },
                floatingActionButton = {
                    if (page == "Home" || page == "Notes") {
                        FloatingActionButton(
                            onClick = { showEditor = true },
                            containerColor = Color(0xFFE4E3E0),
                            contentColor = Black,
                            shape = CircleShape
                        ) { Icon(Icons.Default.Add, contentDescription = "Create note") }
                    }
                }
            ) { insets ->
                AnimatedContent(
                    targetState = page,
                    modifier = Modifier.fillMaxSize().padding(insets),
                    transitionSpec = {
                        (fadeIn(tween(280)) + slideInHorizontally(tween(320)) { it / 14 }) togetherWith
                            (fadeOut(tween(160)) + slideOutHorizontally(tween(220)) { -it / 18 })
                    },
                    label = "page-transition"
                ) { target ->
                    when (target) {
                        "Home" -> HomeScreen(search, { search = it }, entries.size, { page = it }, entries)
                        "Memories" -> PlaceholderScreen("Memories", "A home for the moments you keep.", "Your visual timeline will live here.")
                        "Notes" -> NotesScreen(entries, search, { search = it })
                        "Vault" -> VaultScreen()
                        "Search" -> SearchScreen(search, { search = it }, entries)
                        else -> PlaceholderScreen("Settings", "Make Seam feel like yours.", "Privacy, appearance and local intelligence controls.")
                    }
                }
            }
            if (showEditor) {
                AlertDialog(
                    onDismissRequest = { showEditor = false },
                    title = { Text("A new thought", color = White) },
                    text = {
                        Column {
                            OutlinedTextField(title, { title = it }, label = { Text("Title") })
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(body, { body = it }, label = { Text("Write something…") }, minLines = 4)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (title.isNotBlank() || body.isNotBlank()) {
                                scope.launch { repository.add(title.ifBlank { "Untitled" }, body) }
                            }
                            title = ""; body = ""; showEditor = false
                        }) { Text("Save", color = White) }
                    },
                    dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancel", color = Grey) } },
                    containerColor = Surface
                )
            }
        }
    }
}

@Composable
private fun AmbientBackdrop() {
    val transition = rememberInfiniteTransition(label = "ambient")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "ambient-phase"
    )
    Canvas(Modifier.fillMaxSize()) {
        val x = size.width * (0.18f + phase * 0.55f)
        val y = size.height * (0.10f + (1f - phase) * 0.16f)
        drawRect(Brush.radialGradient(
            colors = listOf(Color(0xFF34363B).copy(alpha = 0.40f), Color(0xFF17191D).copy(alpha = 0.16f), Color.Transparent),
            center = Offset(x, y), radius = size.width * 0.78f
        ))
        val step = 48.dp.toPx()
        for (gx in 0..(size.width / step).toInt()) {
            val xx = gx * step
            drawLine(Color.White.copy(alpha = 0.025f), Offset(xx, 0f), Offset(xx, size.height), 0.7.dp.toPx())
        }
        for (gy in 0..(size.height / step).toInt()) {
            val yy = gy * step
            drawLine(Color.White.copy(alpha = 0.025f), Offset(0f, yy), Offset(size.width, yy), 0.7.dp.toPx())
        }
    }
}

@Composable
private fun SeamWordmark() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        SeamEmblem(32.dp)
        Spacer(Modifier.width(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("SEAM", color = White, fontSize = 13.sp, letterSpacing = 3.2.sp, fontWeight = FontWeight.SemiBold)
            Text("by PaperFlow", color = Grey, fontSize = 10.sp, letterSpacing = .35.sp)
        }
    }
}

@Composable
private fun SeamEmblem(size: Dp) {
    val t = rememberInfiniteTransition(label = "emblem")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "emblem-angle")
    Canvas(Modifier.size(size)) {
        val c = Offset(size.toPx()/2, size.toPx()/2)
        val r = size.toPx()/2
        for (i in 0..2) {
            drawCircle(Color.White.copy(alpha = .75f - i * .16f), r * (.34f + i * .22f),
                style = Stroke(width = 1.dp.toPx()), center = c)
        }
        val rad = Math.toRadians(angle.toDouble())
        val p = Offset(c.x + kotlin.math.cos(rad).toFloat() * r * .39f, c.y + kotlin.math.sin(rad).toFloat() * r * .39f)
        drawCircle(Color.White.copy(alpha = .95f), 1.8.dp.toPx(), p)
    }
}

@Composable
private fun HomeScreen(
    search: String, onSearch: (String) -> Unit, count: Int,
    onNavigate: (String) -> Unit, entries: List<Entry>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SeamWordmark()
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onNavigate("Settings") }) {
                    Icon(Icons.Default.Tune, "Settings", tint = Grey)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Your space,", color = White, fontSize = 34.sp, fontWeight = FontWeight.Light, letterSpacing = (-1.1).sp)
                Text("held together.", color = Silver, fontSize = 34.sp, fontWeight = FontWeight.Light, letterSpacing = (-1.1).sp)
                Text("A quieter place for the things that matter.", color = Grey, fontSize = 13.sp)
            }
        }
        item { SearchField(search, onSearch, "Search memories, thoughts and ideas") }
        item {
            HeroCard(onClick = { onNavigate("Memories") })
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR SPACE", color = Grey, fontSize = 10.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text("$count saved notes", color = Grey, fontSize = 10.sp)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("Memories", "Photos, moments and places", Icons.Default.PhotoLibrary, "Explore your timeline") { onNavigate("Memories") }
                FeatureCard("Notes & reflections", "Thoughts worth keeping", Icons.Default.EditNote, "Open your journal") { onNavigate("Notes") }
                FeatureCard("Password vault", "Your credentials, kept private", Icons.Default.Lock, "Protected space") { onNavigate("Vault") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("RECENTLY ADDED", color = Grey, fontSize = 10.sp, letterSpacing = 2.2.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { onNavigate("Notes") }) { Text("See all", color = Silver, fontSize = 11.sp) }
            }
        }
        if (entries.isEmpty()) {
            item { EmptyState("Nothing here just yet", "Save a thought. Seam will keep it close.") }
        } else {
            items(entries.take(4).size) { i ->
                val entry = entries[i]
                EntryCard(entry.title, entry.body, "NOTE")
            }
        }
    }
}

@Composable
private fun HeroCard(onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "hero-shimmer")
    val sweep by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart), label = "sweep")
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF34363A), Color(0xFF17181B), Color(0xFF101113))))
            .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(25.dp))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MEMORY SPACE", color = Silver.copy(alpha = .78f), fontSize = 9.sp, letterSpacing = 2.1.sp)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ArrowOutward, null, tint = Grey, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().height(104.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val center = Offset(size.width * .52f, size.height * .55f)
                for (i in 0..5) {
                    drawOval(
                        color = Color.White.copy(alpha = .12f - i * .014f),
                        topLeft = Offset(center.x - (32 + i * 14).dp.toPx(), center.y - (15 + i * 8).dp.toPx()),
                        size = androidx.compose.ui.geometry.Size((64 + i * 28).dp.toPx(), (30 + i * 16).dp.toPx()),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                val dotX = (size.width + 80.dp.toPx()) * sweep - 40.dp.toPx()
                drawCircle(Color.White.copy(alpha = .8f), 2.dp.toPx(), Offset(dotX.coerceIn(0f, size.width), center.y))
                drawCircle(Color.White.copy(alpha = .12f), 18.dp.toPx(), Offset(dotX.coerceIn(0f, size.width), center.y))
            }
            Text("A constellation\nof your moments.", color = White, fontSize = 23.sp, lineHeight = 27.sp,
                fontWeight = FontWeight.Light, modifier = Modifier.align(Alignment.CenterStart))
        }
        Spacer(Modifier.height(12.dp))
        Text("Bring the little pieces together.", color = Grey, fontSize = 12.sp)
    }
}

@Composable
private fun SearchField(value: String, onValue: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(hint, color = Grey, fontSize = 12.sp) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Grey) },
        trailingIcon = { Icon(Icons.Default.Tune, null, tint = Grey) },
        singleLine = true, shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Color(0xFF1D1E21), focusedContainerColor = Color(0xFF1D1E21),
            unfocusedBorderColor = Color.White.copy(alpha = .07f), focusedBorderColor = Color.White.copy(alpha = .35f),
            focusedTextColor = White, unfocusedTextColor = White
        )
    )
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, hint: String, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) .985f else 1f, spring(dampingRatio = .62f), label = "card-press")
    Row(
        Modifier.fillMaxWidth().scale(scale).clip(RoundedCornerShape(19.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF202124), Color(0xFF151619))))
            .border(1.dp, Color.White.copy(alpha = .055f), RoundedCornerShape(19.dp))
            .clickable { onClick() }.padding(horizontal = 15.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Color(0xFF090A0C), CircleShape).border(1.dp, Color.White.copy(alpha = .10f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Silver, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Grey, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Grey)
    }
}

@Composable
private fun NotesScreen(entries: List<Entry>, search: String, onSearch: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp).padding(top = 26.dp)) {
        Text("Notes & reflections", color = White, fontSize = 29.sp, fontWeight = FontWeight.Light)
        Text("A place to leave your thoughts.", color = Grey, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp)); SearchField(search, onSearch, "Find a note")
        Spacer(Modifier.height(20.dp))
        if (entries.isEmpty()) EmptyState("Your journal begins here", "Use the + button to write your first note.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(entries.size) { i -> EntryCard(entries[i].title, entries[i].body, "NOTE") } }
    }
}

@Composable
private fun SearchScreen(search: String, onSearch: (String) -> Unit, entries: List<Entry>) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp).padding(top = 26.dp)) {
        Text("Find your thread.", color = White, fontSize = 29.sp, fontWeight = FontWeight.Light)
        Text("Search by words, ideas or remembered details.", color = Grey, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp)); SearchField(search, onSearch, "Try “the idea I had last week”")
        Spacer(Modifier.height(18.dp))
        Text("${entries.size} matches", color = Grey, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(entries.size) { i -> EntryCard(entries[i].title, entries[i].body, "NOTE") } }
    }
}

@Composable
private fun VaultScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Password vault", color = White, fontSize = 29.sp, fontWeight = FontWeight.Light)
        Text("A separate, protected space for credentials.", color = Grey, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF393A3D), Color(0xFF17181B), Color(0xFF0D0E10)))).padding(22.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Shield, null, tint = Silver, modifier = Modifier.size(28.dp))
                Text("Private by design.", color = White, fontSize = 24.sp, fontWeight = FontWeight.Light)
                Text("Vault encryption and biometric unlock are the next security milestone. This starter does not yet store credentials.", color = Grey, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, subtitle: String, detail: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = White, fontSize = 29.sp, fontWeight = FontWeight.Light)
        Text(subtitle, color = Grey, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        EmptyState(detail, "This area is part of the next implementation milestone.")
    }
}

@Composable
private fun EntryCard(title: String, body: String, kind: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).border(1.dp, Color.White.copy(alpha = .05f), RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(title, color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Grey, fontSize = 12.sp, maxLines = 3)
        Spacer(Modifier.height(9.dp))
        Text(kind, color = Silver.copy(alpha = .72f), fontSize = 9.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SeamEmblem(48.dp)
        Text(title, color = White, fontSize = 16.sp, fontWeight = FontWeight.Light)
        Text(subtitle, color = Grey, fontSize = 11.sp)
    }
}

@Composable
private fun SeamBottomBar(selected: String, onSelect: (String) -> Unit) {
    val items = listOf("Home" to Icons.Default.Home, "Memories" to Icons.Default.PhotoLibrary, "Notes" to Icons.Default.EditNote, "Vault" to Icons.Default.Lock, "Search" to Icons.Default.Search)
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 10.dp, top = 8.dp)
            .clip(RoundedCornerShape(28.dp)).background(Color(0xFF1B1C1F).copy(alpha = .97f))
            .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(28.dp))
            .padding(horizontal = 5.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (name, icon) ->
            val active = selected == name
            val scale by animateFloatAsState(if (active) 1.06f else 1f, spring(dampingRatio = .58f), label = "nav-scale")
            Column(
                Modifier.weight(1f).scale(scale).clip(RoundedCornerShape(22.dp))
                    .background(if (active) Color(0xFF343538) else Color.Transparent)
                    .clickable { onSelect(name) }.padding(vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Icon(icon, null, tint = if (active) White else Grey, modifier = Modifier.size(19.dp))
                Text(name, color = if (active) White else Grey, fontSize = 8.sp)
            }
        }
    }
}
