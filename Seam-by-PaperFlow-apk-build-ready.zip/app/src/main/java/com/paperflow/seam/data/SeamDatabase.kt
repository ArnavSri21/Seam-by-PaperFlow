package com.paperflow.seam.data
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="entries")
data class Entry(@PrimaryKey val id:String, val title:String, val body:String, val tags:String="", val updatedAt:Long=System.currentTimeMillis())
@Dao interface EntryDao {
 @Query("SELECT * FROM entries ORDER BY updatedAt DESC") fun all(): Flow<List<Entry>>
 @Query("SELECT * FROM entries WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' OR tags LIKE '%' || :q || '%' ORDER BY updatedAt DESC") fun search(q:String): Flow<List<Entry>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun save(entry:Entry)
}
@Database(entities=[Entry::class],version=1,exportSchema=true)
abstract class SeamDatabase:RoomDatabase(){
 abstract fun entries():EntryDao
 companion object {
  @Volatile private var instance:SeamDatabase?=null
  fun get(context:Context)=instance?: synchronized(this){instance?:Room.databaseBuilder(context,SeamDatabase::class.java,"seam.db").build().also{instance=it}}
 }
}
